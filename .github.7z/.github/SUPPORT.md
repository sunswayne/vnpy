# 获取帮助

在开发和使用VeighNa项目的过程中遇到问题时，获取帮助的渠道包括：

* Github Issues：[Issues页面](https://github.com/vnpy/vnpy/issues)
* 官方QQ群: 262656087
* 项目论坛：[维恩的派](http://www.vnpie.com)
* 项目邮箱: VeighNa@foxmail.com
